#include<stdio.h>
#include<windows.h>
int x,y;
char at[3][3],r,table[34][34],l,t[5],live;

void start();
void showtable(int x1,int y1);
char life();
void playA(char a);
void playB();
void it();

int main(){
	while(1){
		start();
		puts("\nWhat do you want to do next?");
		puts("(A)Play again.  (B)Exit.");
		gets(t);
		if(strcmp(t,"B")==0){
			break;
		}
	}
}
void start(){
	system("cls");
	puts("********************************************");
	puts("Wellcome to our game.");
	puts("Please choose your model:");
	puts("(A)Play with computer. (B)Play with another person.  (C)Exit.");
	while(1){
		gets(t);
		if(strcmp(t,"A")==0){
			puts("********************************************");
			it();
			puts("Please choose level:");
			puts("(A)Hard (B)Normal (C)Easy");
			while(1){
				gets(t);
				if(strcmp(t,"A")==0){
					r='A';
					break;
				}
				else if(strcmp(t,"B")==0){
					r='B';
					break;
				}
				else if(strcmp(t,"C")==0){
					r='C';
					break;
				}
				else{
					puts("We can not understand you.Please tap again.");
					Sleep(1000);
				}
			}
			puts("********************************************");
			puts("Please choose who first:");
			puts("(A)I first. (B)Computer first.");
			while(1){
				gets(t);
				if(strcmp(t,"A")==0){
					system("cls");
					showtable(1,1);
					playA('A');
					break; 
				}
				else if(strcmp(t,"B")==0){
					system("cls");
					showtable(1,1);
					playA('B');
					break;
				}
				else{
					puts("We can not understand you.Please tap again.");
					Sleep(1000);
				}
			}
			break;
		}
		else if(strcmp(t,"B")==0){
			it();
			system("cls");
			showtable(1,1);
			playB();
			break;
		}
		else if(strcmp(t,"C")==0){
			break;
		}
		else{
			puts("We can not understand you.Please tap again.");
			Sleep(3000);
		}
	}
}
void showtable(int x1,int y1){
	if(at[x1][y1]==1){
		for(x=0;x<10;x++){
			table[x1*11+x][y1*11+x]='\\';
		}
		for(x=1;x<10;x++){
			table[x1*11+10-x][y1*11+x]='/';
		}
	}
	else if(at[x1][y1]==2){
		table[x1*11+3][y1*11+5]='*';
		table[x1*11+3][y1*11+6]='*';
		table[x1*11+4][y1*11+3]='*';
		table[x1*11+4][y1*11+8]='*';
		table[x1*11+5][y1*11+2]='*';
		table[x1*11+5][y1*11+9]='*';
		table[x1*11+6][y1*11+2]='*';
		table[x1*11+6][y1*11+9]='*';
		table[x1*11+7][y1*11+3]='*';
		table[x1*11+7][y1*11+8]='*';
		table[x1*11+8][y1*11+5]='*';
		table[x1*11+8][y1*11+6]='*';
	}
	for(x=1;x<34;x++){
		for(y=1;y<34;y++){
			if(table[x][y]==0){
				printf(" ");
			}
			else{
				printf("%c",table[x][y]);
			}
		}
		putchar('\n');
	}
}
void it(){
	for(x=0;x<3;x++){
		for(y=0;y<3;y++){
			at[x][y]=0;
		}
	}
	for(x=0;x<34;x++){
		for(y=0;y<34;y++){
			table[x][y]=0;
		}
	} 
	for(x=1;x<34;x++){
		table[x][11]='|';
		table[x][22]='|';
		table[x][33]='|';
		table[11][x]='-';
		table[22][x]='-';
		table[33][x]='-';
	}
	l=0;
}
void playA(char b){
	l=(b=='A')?1:2;
	while((live=life())==0){
		if(l%2==1){
			gets(t);
			if(t[0]<'4'&&t[0]>'0'&&t[2]<'4'&&t[2]>'0'&&t[1]==' '&&t[3]==0){
				x=t[0]-'0';
				y=t[2]-'0';
				if(at[x-1][y-1]==0){
					at[x-1][y-1]=1;
					l++;
					system("cls");
					showtable(x-1,y-1);
				}
				else{
					puts("That point has been used.Please tap again.");
				}
			}
			else{
				puts("Wrong input,Please tap again.");
			}			
		}
		else{
			int i,j;
			j=-1;
	    	if(r=='A'){
	    		if(!at[1][1]){
	    			i=1;
	    			j=1;
				}
				else{
	    	 		for(x=y=0;x<3;x++,y++){
						if(at[x][0]*at[x][1]==4&&at[x][2]==0){
							i=x;
							j=2;
						}
						else if(at[x][0]*at[x][2]==4&&at[x][1]==0){
							i=x;
							j=1;
						}
						else if(at[x][1]*at[x][2]==4&&at[x][0]==0){
							i=x;
							j=0;
						}
						if(at[0][y]*at[1][y]==4&&at[2][y]==0){
							i=2;
							j=y;
						}
						else if(at[0][y]*at[2][y]==4&&at[1][y]==0){
							i=1;
							j=y;
						}
						else if(at[1][y]*at[2][y]==4&&at[0][y]==0){
							i=0;
							j=y;
						}
					}
					if(at[0][0]*at[1][1]==4&&at[2][2]==0){
						i=2;
					}
					if(at[0][0]*at[2][2]==4&&at[1][1]==0){
						i=1;
						j=1;
					}
					if(at[1][1]*at[2][2]==4&&at[0][0]==0){
						i=0;
						j=0;
					}
					if(at[0][2]*at[1][1]==4&&at[2][0]==0){
						i=2;
						j=0;
					}
					if(at[0][2]*at[2][0]==4&&at[1][1]==0){
						i=1;
						j=1;
					}
					if(at[1][1]*at[2][0]==4&&at[0][2]==0){
						i=0;
						j=2;
					}
				}
				if(j==-1){
	    			for(x=y=0;x<3;x++,y++){
						if(at[x][0]*at[x][1]==1&&at[x][2]==0){
							i=x;
							j=2;
						}
						else if(at[x][0]*at[x][2]==1&&at[x][1]==0){
							i=x;
							j=1;
						}
						else if(at[x][1]*at[x][2]==1&&at[x][0]==0){
							i=x;
							j=0;
						}
						if(at[0][y]*at[1][y]==1&&at[2][y]==0){
							i=2;
							j=y;
						}
						else if(at[0][y]*at[2][y]==1&&at[1][y]==0){
							i=1;
							j=y;
						}
						else if(at[1][y]*at[2][y]==1&&at[0][y]==0){
							i=0;
							j=y;
						}
					} 
					if(at[0][0]*at[1][1]==1&&at[2][2]==0){
						i=2;
						j=2;
					}
					if(at[0][0]*at[2][2]==1&&at[1][1]==0){
						i=1;
						j=1;
					}
					if(at[1][1]*at[2][2]==1&&at[0][0]==0){
						i=0;
						j=0;
					}
					if(at[0][2]*at[1][1]==1&&at[2][0]==0){
						i=2;
						j=0;
					}
					if(at[0][2]*at[2][0]==1&&at[1][1]==0){
						i=1;
						j=1;
					}
					if(at[1][1]*at[2][0]==1&&at[0][2]==0){
						i=0;
						j=2;
					}
					if(j<0){
						srand(time(NULL));
						do{
							i=rand()%3;
							j=rand()%3;
						}while(!(at[i][j]==0));
					}
				}
			}
			else if(r=='B'){	
				if(at[1][1]==0){
					i=1;
					j=1;
				}
				else{
					srand(time(NULL));
					do{
						i=rand()%3;
						j=rand()%3;
					}while(!(at[i][j]==0));
				}
			}
			else if(r=='C'){
				srand(time(NULL));
				do{
					i=rand()%3;
					j=rand()%3;
				}while(!(at[i][j]==0));
			}
			at[i][j]=2;
			l++;
			system("cls");
			printf("%d %d\n",i,j);
			showtable(i,j);
		}
	}
	if(live==1){
		puts("You win!");
	}
	else if(live==2){
		puts("Computer win!");
	}
	else{
		puts("Draw!");
	}
} 
void playB(){
	while((live=life())==0){
		gets(t);
		if(t[0]<'4'&&t[0]>'0'&&t[2]<'4'&&t[2]>'0'&&t[1]==' '&&t[3]==0){
			x=t[0]-'0';
			y=t[2]-'0';
			if(at[x-1][y-1]==0){
				at[x-1][y-1]=l%2+1;
				l++;
				system("cls");
				showtable(x-1,y-1);
			}
			else{
				puts("That point has been used.Please tap again.");
			}
		}
		else{
			puts("Wrong input,Please tap again.");
		}
	}
	if(live==3){
		printf("Draw!");
	}
	else{
		printf("Player%d win!\n",live);
	}
}
char life(){
	for(x=0;x<3;x++){
		if(at[x][0]==at[x][1]&&at[x][1]==at[x][2]&&at[x][1]!=0){
			return at[x][0];
		}
		if(at[0][x]==at[1][x]&&at[1][x]==at[2][x]&&at[1][x]!=0){
			return at[1][x];
		}
	}
	if(at[0][2]==at[1][1]&&at[1][1]==at[2][0]&&at[0][2]!=0){
		return at[0][2];
	}
	if(at[0][0]==at[1][1]&&at[0][0]==at[2][2]&&at[0][0]!=0){
		return at[2][2];
	}
	for(x=0;x<3;x++){
		for(y=0;y<3;y++){
			if(at[x][y]==0){
				return 0;
			}
		}
	}
	return 3;
}
