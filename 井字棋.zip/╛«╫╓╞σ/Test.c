#include<stdio.h>
int x,y;
char at[3][3];

void block(){
	int i,j,f;
	x=6;
	for(i=0;i<3;i++){
		if(at[0][i]==1){
			f++;
		}
		else if(at[0][i]==2){
			f--;
		}
		else{
			x=0;
			y=i;
		}
	}
	if(f==2&&x==0){
		at[x][y]=1;
	}
}
int main(){
	
}
